export enum Modules {
  USER_MODULE = 'USER_MODULE',
}
