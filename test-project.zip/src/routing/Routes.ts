export enum Routes {
  USERS = 'USERS'
}
