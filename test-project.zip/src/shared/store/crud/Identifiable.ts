export interface Identifiable {
  id: number;
}
